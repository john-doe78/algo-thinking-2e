This code accompanies the book 
Algorithmic Thinking, 2nd Edition
by
Daniel Zingaro

https://nostarch.com/algorithmic-thinking-2nd-edition

